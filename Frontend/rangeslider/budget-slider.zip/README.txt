A Pen created at CodePen.io. You can find this one at https://codepen.io/khadkamhn/pen/qbPQrv.

 An example of experiment with range slider plugin of jquery.

Credits:
---------------
<ul>
<li>Google font available at <a href="http://www.google.com/fonts/specimen/Roboto" target="_blank">Roboto</a></li>
<li>Slider Range plugin by <a href="https://andreruffert.github.io/rangeslider.js/" target="_blank">André Ruffert</a></li>
<li>Awesome dribbble shot by <a href="https://dribbble.com/shots/2448385-Day-96-Budget-Slider" target="_blank">Bence Vitarius</a></li>
</ul>
<em>I'm glad for using these resources and expecting same as time ahead</em>